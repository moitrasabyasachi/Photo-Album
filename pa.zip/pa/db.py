host = 'localhost'
user = 'root'
password = ''
database = 'photo_album'
